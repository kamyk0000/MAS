package proj_1;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Animal implements Serializable {

    // Atrybut klasowy
    private static int nextID = 0;
    // Atrybuty proste
    private int ID;
    private String name;
    private String species;
    private String gender;
    private double weight;
    // Atrybut złożony
    private final LocalDate birthDate;
    // Atrybut opcjonalny
    private List<String> medicalHistory = new ArrayList<>();
    // Atrybut powtarzalny
    private List<String> owners = new ArrayList<>();
    // Atrybut pochodny
    public int getAge() {
        return LocalDate.now().getYear() - birthDate.getYear();
    }
    // Ekstensja
    private static List<Animal> extent = new ArrayList<>();
    // Metody ekstensji
    public static void showExtent() {
        if (extent.isEmpty()){
            System.out.println("Extent is empty");
        }
        for (Animal animal : extent) { System.out.println(animal); }
    }
    // Trwałość ekstensji
    private static final String EXTENT_FILE_NAME = "animals.json";

    public static void saveExtent() {

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(EXTENT_FILE_NAME))) {
            out.writeObject(extent);
            System.out.println(extent.size() + " objects in the Extent saved successfully.");
        } catch (IOException e) {
            System.err.println("Error occurred while saving extent: " + e.getMessage());
        }
    }

    public static void loadExtent() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(EXTENT_FILE_NAME))) {
            extent = (List<Animal>) in.readObject();
            System.out.println(extent.size() + " objects loaded with the Extent successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error occurred while loading extent: " + e.getMessage());
        }
    }

    public static void addAnimal(Animal animal) {
        extent.add(animal);
    }

    public static void removeAnimal(Animal animal) {
        extent.remove(animal);
    }

    // Metody klasowe
    public static Animal create (String name, String species, String gender, double weight, LocalDate birthDate, String owner) throws Exception {
        if (name == null || species == null || gender == null || birthDate == null || owner == null) {
            throw new Exception("Arguments cannot be null");
        }
        Animal animal = new Animal(name, species, gender, weight, birthDate, owner);
        addAnimal(animal);
        return animal;
    }

    public static Animal getAnimal (int ID) throws Exception {
        for (Animal animal : extent) {
            if (animal.ID == ID) return animal;
        }
        throw new Exception("Animal of ID: " + ID + " not found");
    }

    private Animal(String name, String species, String gender, double weight, LocalDate birthDate, String owner) {
        this.ID = nextID++;
        this.name = name;
        this.species = species;
        this.gender = gender;
        this.weight = weight;
        this.birthDate = birthDate;
        this.owners.add(owner);
        //extent.add(this);
    }

    // Metody obiektowe
    public void addOwner (String owner) {
        this.owners.add(owner);
    }

    public void addMedicalRecord(String record) {
        this.medicalHistory.add(LocalDate.now() + ": " + record);
    }

    // Przeciążenie metody obiektowej
    public void addMedicalRecord(String record, LocalDate specificDate) {
        this.medicalHistory.add(specificDate.toString() + ": " + record);
    }

    public void showMedicalRecords() {
        if (this.medicalHistory.isEmpty()) {
            System.out.println("Medical history not found");
        }else {
            for (String str:medicalHistory) {
                System.out.println(str);
            }
        }
    }

    public String showOwners () {
        StringBuilder ownerBuilder = new StringBuilder();
        ownerBuilder.append(owners.get(0));
        boolean isFirst = true;
        for (String owner : owners){
            if (isFirst) {
                isFirst = false;
                continue;
            }
            ownerBuilder.append(", ").append(owner);
        }
        return ownerBuilder.toString();
    }

    // Przesłonięcie metody
    @Override
    public String toString() {
        return "Animal[" + ID +
                "] -> name: " + name +
                ", species: " + species  +
                ", gender: " + gender +
                ", weight: " + weight +
                ", age: " + getAge() +
                ", owners: " + showOwners();
    }
}
